﻿$("#submitButton").click(function () {

    //Define variables
    var assignments = $("#assignments").val();
    var projects = $("#groupProjects").val();
    var quizzes = $("#quizzes").val();
    var exams = $("#exams").val();
    var intex = $("#intex").val();

    //Calculate score
    var score = (assignments * 0.5) + (projects * 0.1) + (quizzes * 0.1) + (exams * 0.2) + (intex * 0.1);

    //Calculate grade letter
    var gradeLetter;
    if (score > 90) {
        gradeLetter = "A";
    } else if (score > 80) {
        gradeLetter = "B";
    } else if (score > 70) {
        gradeLetter = "C";
    } else if (score > 60) {
        gradeLetter = "D";
    } else {
        gradeLetter = "E";
    }

    alert("Score: " + score + ", Grade Letter: " + gradeLetter);
});